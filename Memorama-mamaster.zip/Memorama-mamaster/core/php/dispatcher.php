<?php

function helloWorld(){
    $greeting = "Hello World";
    echo $greeting;
}

helloWorld();